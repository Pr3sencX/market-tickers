# market_tickers/__init__.py

from market_tickers.core import get_ticker, get_default_index
